//: Playground - noun: a place where people can play

import UIKit

// This section will define all of the variables.

let var1 = 421;
let var2 = 23;
let var3 = 2;


// This section will define all of the operations.

var op1 = var1 + var2
var op2 = var2 - var3
var op3 = var2 * var1
var op4 = var1 / var2
var op5 = var1 % var2

// This section will print out all of the operations.

print(op1, "is", var1, "plus", var2)
print(op2, "is", var2, "minus", var3)
print(op3, "is", var2, "times", var1)
print(op4, "is", var1, "divide by", var2)
print(op5, "is the remainder of", var1, "divided by", var2)